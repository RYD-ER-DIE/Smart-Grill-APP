package com.example.smartgrill;

import android.bluetooth.BluetoothSocket;

public class MyBluetoothSocketHolder {
    private static final MyBluetoothSocketHolder instance = new MyBluetoothSocketHolder();
    private BluetoothSocket socket;

    private MyBluetoothSocketHolder() {}

    public static MyBluetoothSocketHolder getInstance() {
        return instance;
    }

    public void setSocket(BluetoothSocket socket) {
        this.socket = socket;
    }

    public BluetoothSocket getSocket() {
        return socket;
    }
}