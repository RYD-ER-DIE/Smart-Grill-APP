package com.example.smartgrill;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

public class ChargeControllerActivity extends AppCompatActivity {

    private static final String TAG = "bluetooth";
    private Handler handler;
    private InputStream inputStream;
    private static final int REQUEST_PERMISSIONS = 1;
    private static final String CCHC06_ADDRESS = "00:23:09:01:6A:29";//replace with panel address
    private static final UUID CCHC06_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;

    private Runnable dataReceiver;

    private GraphView graph;
    private LineGraphSeries<DataPoint> chargeCurrentSeries;
    private LineGraphSeries<DataPoint> loadCurrentSeries;
    private LineGraphSeries<DataPoint> panelVoltageSeries;
    private LineGraphSeries<DataPoint> batteryVoltageSeries;
    //private LineGraphSeries<DataPoint> series;
    private int lastX = 0;

    private TextView chargeCurrentValue;
    private TextView panelVoltageValue;
    private TextView batteryVoltageValue;
    private TextView loadCurrentValue;

    private Button startButton;
    private Button connectButton;
    private Button summaryButton;
    private Button toTEMPButton;

    private StringBuilder dataBuffer = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charge_controller);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        graph = findViewById(R.id.chargeCurrentGraph);

        chargeCurrentSeries = new LineGraphSeries<>();
        graph.addSeries(chargeCurrentSeries);
        loadCurrentSeries = new LineGraphSeries<>();
        graph.addSeries(loadCurrentSeries);
        panelVoltageSeries = new LineGraphSeries<>();
        graph.addSeries(panelVoltageSeries);
        batteryVoltageSeries = new LineGraphSeries<>();
        graph.addSeries(batteryVoltageSeries);

        // Enable scaling and scrolling
        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);
        graph.getViewport().setScrollable(false);
        graph.getViewport().setScrollableY(false);

        // Set padding and margin for y-axis labels
        graph.getGridLabelRenderer().setPadding(40);  // Adjust this value if needed

        chargeCurrentValue = findViewById(R.id.chargeCurrentValue);
        panelVoltageValue = findViewById(R.id.panelVoltageValue);
        batteryVoltageValue = findViewById(R.id.batteryVoltageValue);
        loadCurrentValue = findViewById(R.id.loadCurrentValue);

        startButton = findViewById(R.id.CCstartButton);
        connectButton = findViewById(R.id.CCconnectButton);
        summaryButton = findViewById(R.id.CCsummaryButton);
        toTEMPButton = findViewById(R.id.toTEMPButton);

        handler = new Handler();

        startButton.setOnClickListener(v -> startDataCollection());
        connectButton.setOnClickListener(v -> connectTOccHC06());

        toTEMPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChargeControllerActivity.this,TemperatureMonitorActivity.class);
                startActivity(intent);
            }
        });

        summaryButton.setOnClickListener(v -> {
            Intent intent = new Intent(ChargeControllerActivity.this, CCSummaryActivity.class);
            //intent.putExtra("CCdataPoints", (Serializable) CCallDataPoints);
            ChargeControllerActivity.this.startActivity(intent);
        });
        requestPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Reset charge current data
        chargeCurrentSeries.resetData(new DataPoint[]{});
        // load charge current data
        List<DataPoint> savedChargeCurrentData = DataHolder.getInstance().getChargeCurrentData();
        for (DataPoint dataPoint : savedChargeCurrentData) {
            chargeCurrentSeries.appendData(dataPoint, true, 300);
        }

        // Reset panel voltage data
        panelVoltageSeries.resetData(new DataPoint[]{});
        //load panel voltage data
        List<DataPoint> savedPanelVoltageData = DataHolder.getInstance().getPanelVoltageData();
        for (DataPoint dataPoint : savedPanelVoltageData) {
            panelVoltageSeries.appendData(dataPoint, true, 300);
        }

        // Reset battery voltage data
        batteryVoltageSeries.resetData(new DataPoint[]{});
        //load battery voltage data
        List<DataPoint> savedBatteryVoltageData = DataHolder.getInstance().getBatteryVoltageData();
        for (DataPoint dataPoint : savedBatteryVoltageData) {
            batteryVoltageSeries.appendData(dataPoint, true, 300);
        }
    }

    private void startDataCollection() {
        BluetoothSocket bluetoothSocket = CCBluetoothSocketHolder.getInstance().getSocket();
        if (bluetoothSocket == null) {
            Toast.makeText(this, "No CC Bluetooth connection", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            inputStream = bluetoothSocket.getInputStream();
        } catch (IOException e) {
            Log.e(TAG, "Failed to get CC input stream", e);
            return;
        }

        dataReceiver = new Runnable() {
            @Override
            public void run() {
                byte[] buffer = new byte[1024];
                int bytes;

                try {
                    while (inputStream.available() > 0) {
                        bytes = inputStream.read(buffer);
                        String data = new String(buffer, 0, bytes);
                        Log.d(TAG, "Received CC data: " + data);

                        dataBuffer.append(data);

                        int endOfLineIndex = dataBuffer.indexOf(";");
                        while (endOfLineIndex > 0) {
                            String completeData = dataBuffer.substring(0, endOfLineIndex).trim();
                            dataBuffer.delete(0, endOfLineIndex + 1);

                            String[] CCData = completeData.split(",");
                            if (CCData.length == 4) {
                                try {
                                    double chargeCurrent = Double.parseDouble(CCData[0]);
                                    double panelVoltage = Double.parseDouble(CCData[1]);
                                    double batteryVoltage = Double.parseDouble(CCData[2]);
                                    double loadCurrent = Double.parseDouble(CCData[3]);

                                    runOnUiThread(() -> {
                                        // displayed data
                                        chargeCurrentValue.setText("Charge Current: " + chargeCurrent + "A");
                                        panelVoltageValue.setText("Panel Voltage: " + panelVoltage + "V");
                                        batteryVoltageValue.setText("Battery Voltage: " + batteryVoltage + "V");
                                        loadCurrentValue.setText("Load Current: " + loadCurrent + "A");

                                        // Graphed Data
                                        chargeCurrentSeries.appendData(new DataPoint(lastX++, chargeCurrent), true, 300);
                                        //loadCurrentSeries.appendData(new DataPoint(lastX++, loadCurrent), true, 300);
                                        //panelVoltageSeries.appendData(new DataPoint(lastX++, panelVoltage), true, 300);
                                        //batteryVoltageSeries.appendData(new DataPoint(lastX++, batteryVoltage), true, 300);

                                        // data to be saved in DataHolder
                                        DataHolder.getInstance().addChargeCurrentData(new DataPoint(lastX, chargeCurrent));
                                        DataHolder.getInstance().addLoadCurrentData(new DataPoint(lastX, loadCurrent));
                                        DataHolder.getInstance().addPanelVoltageData(new DataPoint(lastX, panelVoltage));
                                        DataHolder.getInstance().addBatteryVoltageData(new DataPoint(lastX, batteryVoltage));

                                        // Update graph scaling dynamically
                                        double lowestY = chargeCurrentSeries.getLowestValueY();
                                        double highestY = chargeCurrentSeries.getHighestValueY();
                                        graph.getViewport().setMinX(Math.max(0, lastX - 300));
                                        graph.getViewport().setMaxX(lastX);
                                        graph.getViewport().setMinY(lowestY - 10);
                                        graph.getViewport().setMaxY(highestY + 10);

                                    });
                                } catch (NumberFormatException e) {
                                    Log.e(TAG, "Invalid number format in CC data: " + completeData, e);
                                }
                            }
                            endOfLineIndex = dataBuffer.indexOf(";");
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error reading CC  data", e);
                }

                handler.postDelayed(this, 1000);
            }
        };
        handler.post(dataReceiver);
    }
    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    android.Manifest.permission.BLUETOOTH_CONNECT,
                    android.Manifest.permission.BLUETOOTH_SCAN,
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }
    @SuppressLint("MissingPermission")
    private void connectTOccHC06() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available on this device", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Bluetooth is not enabled", Toast.LENGTH_SHORT).show();
            return;
        }

        BluetoothDevice hc06 = bluetoothAdapter.getRemoteDevice(CCHC06_ADDRESS);

        new Thread(() -> {
            try {
                bluetoothSocket = hc06.createRfcommSocketToServiceRecord(CCHC06_UUID);
                bluetoothSocket.connect();
                CCBluetoothSocketHolder.getInstance().setSocket(bluetoothSocket);  // Save socket in the holder
            } catch (IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(ChargeControllerActivity.this, "Failed to connect to CCHC-06", Toast.LENGTH_SHORT).show();

                });
                Log.e("Bluetooth", "Error connecting to CCHC-06", e);
                CCBluetoothSocketHolder.getInstance().setSocket(null);
            }
        }).start();
    }
}