package com.example.smartgrill;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button toTEMPButton = findViewById(R.id.toTEMPButton);
        Button toCCButton = findViewById(R.id.toCCButton);

        toCCButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ChargeControllerActivity.class);
                startActivity(intent);
            }
        });

        toTEMPButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TemperatureMonitorActivity.class);
                startActivity(intent);
            }
        });
    }
}