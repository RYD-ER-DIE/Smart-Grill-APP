package com.example.smartgrill;

import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.List;

public class CCSummaryActivity extends AppCompatActivity {

    private GraphView summaryGraph;
    private LineGraphSeries<DataPoint> summarySeries;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ccsummary);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        summaryGraph = findViewById(R.id.summaryGraph);

        //separate series for each type of data
        LineGraphSeries<DataPoint> chargeCurrentSeries = new LineGraphSeries<>();
        LineGraphSeries<DataPoint> loadCurrentSeries = new LineGraphSeries<>();
        LineGraphSeries<DataPoint> panelVoltageSeries = new LineGraphSeries<>();
        LineGraphSeries<DataPoint> batteryVoltageSeries = new LineGraphSeries<>();

        // Retrieve ChargeController data points from DataHolder
        List<DataPoint> chargeCurrentData = DataHolder.getInstance().getChargeCurrentData();
        List<DataPoint> loadCurrentData = DataHolder.getInstance().getLoadCurrentData();
        List<DataPoint> panelVoltageData = DataHolder.getInstance().getPanelVoltageData();
        List<DataPoint> batteryVoltageData = DataHolder.getInstance().getBatteryVoltageData();

        if (!chargeCurrentData.isEmpty()) {
            for (DataPoint point : chargeCurrentData) {
                chargeCurrentSeries.appendData(point, true, chargeCurrentData.size());
            }
        }
        if (!loadCurrentData.isEmpty()) {
            for (DataPoint point : loadCurrentData) {
                loadCurrentSeries.appendData(point, true, loadCurrentData.size());
            }
        }
        if (!panelVoltageData.isEmpty()) {
            for (DataPoint point : panelVoltageData) {
                panelVoltageSeries.appendData(point, true, panelVoltageData.size());
            }
        }
        if (!batteryVoltageData.isEmpty()) {
            for (DataPoint point : batteryVoltageData) {
                batteryVoltageSeries.appendData(point, true, batteryVoltageData.size());
            }
        }

        // Customize colors for each series
        chargeCurrentSeries.setColor(Color.CYAN);
        loadCurrentSeries.setColor(Color.GREEN);
        panelVoltageSeries.setColor(Color.MAGENTA);
        batteryVoltageSeries.setColor(Color.RED);

        // Add series to the graph
        summaryGraph.addSeries(chargeCurrentSeries);
        summaryGraph.addSeries(loadCurrentSeries);
        summaryGraph.addSeries(panelVoltageSeries);
        summaryGraph.addSeries(batteryVoltageSeries);

        // Set label formatter and scaling options
        summaryGraph.getGridLabelRenderer().setLabelFormatter(new TimeLabelFormatter());
        summaryGraph.getViewport().setXAxisBoundsManual(true);
        summaryGraph.getViewport().setYAxisBoundsManual(true);
        summaryGraph.getViewport().setMinX(0);
        summaryGraph.getViewport().setMaxX(chargeCurrentData.size()); // Adjust based on data size

        // Set Y-axis bounds based on all series data if available
        double minY = Math.min(
                Math.min(chargeCurrentSeries.getLowestValueY(), loadCurrentSeries.getLowestValueY()),
                Math.min(panelVoltageSeries.getLowestValueY(), batteryVoltageSeries.getLowestValueY())
        );
        double maxY = Math.max(
                Math.max(chargeCurrentSeries.getHighestValueY(), loadCurrentSeries.getHighestValueY()),
                Math.max(panelVoltageSeries.getHighestValueY(), batteryVoltageSeries.getHighestValueY())
        );
        summaryGraph.getViewport().setMinY(minY - 10);
        summaryGraph.getViewport().setMaxY(maxY + 10);

        summaryGraph.getViewport().setScalable(true);
        summaryGraph.getViewport().setScalableY(true);

        // Text box for displaying labels
        //TextView dataInfoText = findViewById(R.id.dataInfoText);
        //dataInfoText.setText("Charge Current (A)\nLoad Current (A)\nPanel Voltage (V)\nPanel Current (A)");
    }
    }