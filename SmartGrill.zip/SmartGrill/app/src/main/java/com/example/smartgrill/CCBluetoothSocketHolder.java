package com.example.smartgrill;

import android.bluetooth.BluetoothSocket;

public class CCBluetoothSocketHolder {
    private static final CCBluetoothSocketHolder instance = new CCBluetoothSocketHolder();
    private BluetoothSocket socket;

    private CCBluetoothSocketHolder() {
    }

    public static CCBluetoothSocketHolder getInstance() {
        return instance;
    }

    public void setSocket(BluetoothSocket socket) {
        this.socket = socket;
    }
    public BluetoothSocket getSocket() { return socket;}
}