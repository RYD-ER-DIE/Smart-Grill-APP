package com.example.smartgrill;

import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;


import java.util.List;

public class SummaryActivity extends AppCompatActivity {

    private GraphView summaryGraph;
    private LineGraphSeries<DataPoint> summarySeries;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        summaryGraph = findViewById(R.id.summaryGraph);
        summarySeries = new LineGraphSeries<>();
        summaryGraph.addSeries(summarySeries);

// Retrieve data points from DataHolder
        List<DataPoint> dataPoints = DataHolder.getInstance().getTemperatureDataPoints();
        if (dataPoints != null && !dataPoints.isEmpty()) {
            for (DataPoint point : dataPoints) {
                summarySeries.appendData(point, true, dataPoints.size());
            }
        } else {
            Toast.makeText(this, "No data available", Toast.LENGTH_SHORT).show();
        }

        // Set the custom label formatter x axis
        summaryGraph.getGridLabelRenderer().setLabelFormatter(new TimeLabelFormatter());

        // Update graph scaling
        summaryGraph.getViewport().setXAxisBoundsManual(true);
        summaryGraph.getViewport().setYAxisBoundsManual(true);
        summaryGraph.getViewport().setMinX(0);
        summaryGraph.getViewport().setMaxX(dataPoints.size());

        //dynamically fit y axis to data
        summaryGraph.getViewport().setMinY(summarySeries.getLowestValueY() - 10);
        summaryGraph.getViewport().setMaxY(summarySeries.getHighestValueY() + 10);

        // Enable zoom and scroll
        summaryGraph.getViewport().setScalable(true);
        summaryGraph.getViewport().setScalableY(true);
    }
}