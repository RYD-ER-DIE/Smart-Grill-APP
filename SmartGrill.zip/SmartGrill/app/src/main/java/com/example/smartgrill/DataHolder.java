package com.example.smartgrill;

import com.jjoe64.graphview.series.DataPoint;
import java.util.ArrayList;
import java.util.List;


public class DataHolder {
    private static DataHolder instance;
    //data from separate activities
    private List<DataPoint> temperatureDataPoints;
    private List<DataPoint> chargeCurrentData;
    private List<DataPoint> loadCurrentData;
    private List<DataPoint> panelVoltageData;
    private List<DataPoint> batteryVoltageData;

    private DataHolder() {
        temperatureDataPoints = new ArrayList<>();
        chargeCurrentData = new ArrayList<>();
        loadCurrentData = new ArrayList<>();
        panelVoltageData = new ArrayList<>();
        batteryVoltageData = new ArrayList<>();
    }

    public static synchronized DataHolder getInstance() {
        if (instance == null) {
            instance = new DataHolder();
        }
        return instance;
    }

    // Temperature Data Methods
    public List<DataPoint> getTemperatureDataPoints() {

        return temperatureDataPoints;
    }

    public void addTemperatureDataPoint(DataPoint dataPoint) {
        temperatureDataPoints.add(dataPoint);
    }

    // Charge Controller Data Methods
    public synchronized void addChargeCurrentData(DataPoint dataPoint) {
        chargeCurrentData.add(dataPoint);
    }

    public synchronized void addLoadCurrentData(DataPoint dataPoint) {
        loadCurrentData.add(dataPoint);
    }

    public synchronized void addPanelVoltageData(DataPoint dataPoint) {
        panelVoltageData.add(dataPoint);
    }

    public synchronized void addBatteryVoltageData(DataPoint dataPoint) {
        batteryVoltageData.add(dataPoint);
    }

    // Methods to retrieve each list of data points
    public List<DataPoint> getChargeCurrentData() {
        return new ArrayList<>(chargeCurrentData);
    }

    public List<DataPoint> getLoadCurrentData() {
        return new ArrayList<>(loadCurrentData);
    }

    public List<DataPoint> getPanelVoltageData() {
        return new ArrayList<>(panelVoltageData);
    }

    public List<DataPoint> getBatteryVoltageData() {
        return new ArrayList<>(batteryVoltageData);
    }

    // Optional: Clear data
    public void clearAllData() {
        temperatureDataPoints.clear();
        chargeCurrentData.clear();
        loadCurrentData.clear();
        panelVoltageData.clear();
        batteryVoltageData.clear();
    }
}

/* original separated data streams
public class DataHolder {
    private static DataHolder instance;
    private List<DataPoint> allDataPoints;

    private DataHolder() {
        allDataPoints = new ArrayList<>();
    }

    public static synchronized DataHolder getInstance() {
        if (instance == null) {
            instance = new DataHolder();
        }
        return instance;
    }

    public List<DataPoint> getAllDataPoints() {
        return allDataPoints;
    }

    public void addDataPoint(DataPoint dataPoint) {
        allDataPoints.add(dataPoint);
    }
}*/