package com.example.smartgrill;

import com.jjoe64.graphview.DefaultLabelFormatter;

public class TimeLabelFormatter extends DefaultLabelFormatter {

    @Override
    public String formatLabel(double value, boolean isValueX) {
        if (isValueX) {
            // Convert seconds to hours:minutes:seconds format
            int hours = (int) value / 3600;
            int minutes = ((int) value % 3600) / 60;
            return hours + ":" + String.format("%02d", minutes);
        } else {
            return super.formatLabel(value, isValueX);
        }
    }
}
