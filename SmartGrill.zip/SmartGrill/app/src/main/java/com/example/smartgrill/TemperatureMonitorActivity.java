package com.example.smartgrill;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

public class TemperatureMonitorActivity extends AppCompatActivity {

    private static final String TAG = "bluetooth";
    private Handler handler;
    private InputStream inputStream;
    private static final int REQUEST_PERMISSIONS = 1;
    private static final String HC06_ADDRESS = "00:14:03:06:0F:2B";
    private static final UUID HC06_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private Runnable dataReceiver;
    private GraphView graph;
    private LineGraphSeries<DataPoint> series;
    private int lastX = 0;

    private TextView cookTempTextView;
    private TextView meat1TempTextView;
    private TextView meat2TempTextView;

    private Button startButton;
    private Button connectButton;
    private Button summaryButton;
    private Button toCCButton;

    private StringBuilder dataBuffer = new StringBuilder();
    //private List<DataPoint> allDataPoints = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature_monitor);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        graph = findViewById(R.id.temperatureGraph);
        series = new LineGraphSeries<>();
        graph.addSeries(series);

        // Enable scaling and scrolling
        graph.getViewport().setScalable(true);
        graph.getViewport().setScalableY(true);
        graph.getViewport().setScrollable(false);
        graph.getViewport().setScrollableY(false);

        // Set padding and margin to ensure y-axis labels are visible
        graph.getGridLabelRenderer().setPadding(40);  // Adjust this value if needed

        cookTempTextView = findViewById(R.id.cookTempTextView);
        meat1TempTextView = findViewById(R.id.meat1TempTextView);
        meat2TempTextView = findViewById(R.id.meat2TempTextView);

        startButton = findViewById(R.id.startButton);
        summaryButton = findViewById(R.id.summaryButton);
        connectButton = findViewById(R.id.connectButton);
        toCCButton = findViewById(R.id.toCCButton);

        handler = new Handler();

        startButton.setOnClickListener(v -> startDataCollection());
        connectButton.setOnClickListener(v -> connectToHC06());


        toCCButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TemperatureMonitorActivity.this, ChargeControllerActivity.class);
                TemperatureMonitorActivity.this.startActivity(intent);
            }
        });

        summaryButton.setOnClickListener(v -> {
            Intent intent = new Intent(TemperatureMonitorActivity.this, SummaryActivity.class);
            startActivity(intent);
        });
        requestPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Clear current graph data
        series.resetData(new DataPoint[]{});

        // Load saved temperature data from DataHolder
        List<DataPoint> savedTemperatureData = DataHolder.getInstance().getTemperatureDataPoints();
        for (DataPoint dataPoint : savedTemperatureData) {
            series.appendData(dataPoint, true, 300);
        }

        // Set lastX to continue where it left off, if data exists
        if (!savedTemperatureData.isEmpty()) {
            lastX = (int) savedTemperatureData.get(savedTemperatureData.size() - 1).getX() + 1;
        }
    }
    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    android.Manifest.permission.BLUETOOTH_CONNECT,
                    android.Manifest.permission.BLUETOOTH_SCAN,
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }
    @SuppressLint("MissingPermission")
    private void connectToHC06() {
        if (bluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available on this device", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Toast.makeText(this, "Bluetooth is not enabled", Toast.LENGTH_SHORT).show();
            return;
        }

        BluetoothDevice hc06 = bluetoothAdapter.getRemoteDevice(HC06_ADDRESS);
        new Thread(() -> {
            try {
                bluetoothSocket = hc06.createRfcommSocketToServiceRecord(HC06_UUID);
                bluetoothSocket.connect();
                MyBluetoothSocketHolder.getInstance().setSocket(bluetoothSocket); // Save socket in holder

             //   runOnUiThread(() -> {
             //       Toast.makeText(TemperatureMonitorActivity.this, "Connected to HC-06", Toast.LENGTH_SHORT).show();
             //       MyBluetoothSocketHolder.getInstance().setSocket(bluetoothSocket);  // Save socket in the holder
             //   });
            } catch (IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(TemperatureMonitorActivity.this, "Failed to connect to HC-06", Toast.LENGTH_SHORT).show();
                });
                Log.e("Bluetooth", "Error connecting to HC-06", e);
            }
        }).start();
    }

    private void startDataCollection() {
        BluetoothSocket bluetoothSocket = MyBluetoothSocketHolder.getInstance().getSocket();
        if (bluetoothSocket == null) {
            Toast.makeText(this, "No Bluetooth connection", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            inputStream = bluetoothSocket.getInputStream();
        } catch (IOException e) {
            Log.e(TAG, "Failed to get input stream", e);
            return;
        }

        dataReceiver = new Runnable() {
            @Override
            public void run() {
                byte[] buffer = new byte[1024];
                int bytes;

                try {
                    while (inputStream.available() > 0) {
                        bytes = inputStream.read(buffer);
                        String data = new String(buffer, 0, bytes);
                        Log.d(TAG, "Received data: " + data);

                        dataBuffer.append(data);

                        int endOfLineIndex = dataBuffer.indexOf(";");
                        while (endOfLineIndex > 0) {
                            String completeData = dataBuffer.substring(0, endOfLineIndex).trim();
                            dataBuffer.delete(0, endOfLineIndex + 1);

                            String[] tempData = completeData.split(",");
                            if (tempData.length == 3) {
                                try {

                                    double meat1Temp = Double.parseDouble(tempData[0]);
                                    double meat2Temp = Double.parseDouble(tempData[1]);
                                    double cookTemp = Double.parseDouble(tempData[2]);
                                    runOnUiThread(() -> {
                                        cookTempTextView.setText("Cook Temperature: " + cookTemp + "°F");
                                        meat1TempTextView.setText("Meat 1 Temperature: " + meat1Temp + "°F");
                                        meat2TempTextView.setText("Meat 2 Temperature: " + meat2Temp + "°F");

                                        DataPoint dataPoint = new DataPoint(lastX++, cookTemp);
                                        series.appendData(dataPoint, true, 300);

                                        // Save data points in data holder
                                        DataHolder.getInstance().addTemperatureDataPoint(dataPoint);

                                        // Update graph scaling dynamically
                                        double lowestY = series.getLowestValueY();
                                        double highestY = series.getHighestValueY();
                                        graph.getViewport().setMinX(Math.max(0, lastX - 300));
                                        graph.getViewport().setMaxX(lastX);
                                        graph.getViewport().setMinY(lowestY - 10);
                                        graph.getViewport().setMaxY(highestY + 10);
                                    });
                                } catch (NumberFormatException e) {
                                    Log.e(TAG, "Invalid number format in data: " + completeData, e);
                                }
                            }
                            endOfLineIndex = dataBuffer.indexOf(";");
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, "Error reading data", e);
                }

                handler.postDelayed(this, 1000);
            }
        };
        handler.post(dataReceiver);
    }
}